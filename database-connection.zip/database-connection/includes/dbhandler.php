<?php 
//xampp default values

$dbServerName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "login-sys";

$connection = mysqli_connect($dbServerName,$dbUsername,$dbPassword,$dbName);